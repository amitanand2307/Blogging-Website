<?php
ob_start();
session_start();
require 'connect.php';

session_destroy();
//echo 'logout';
header('Location: index.php');
?>