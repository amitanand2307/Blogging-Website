
<?php
ob_start();
session_start();
require 'connect.php';


$id_reply;

  foreach($_POST as $name => $content) { // Most people refer to $key => $value
   if(is_int($name))
      $id_reply = $name;
}



if(isset($_SESSION['user_id']))
{

  if(isset($_POST[$id_reply]) && !empty($_POST[$id_reply]))
  {
    $id_title = $id_reply;
    $reply = $_POST[$id_reply];
    $username = $_SESSION['username'];
    $query="INSERT INTO `replies` (id_title,reply,username) VALUES("."'".$id_title."'".","."'".$reply."'".","."'".$username."'".")";
    
  if($query_run=mysql_query($query))
  {
    $_SESSION['reply'] = 'Your reply got successfully submitted';    
  } 
  else
  {
    $_SESSION['reply'] = 'wrong query';
  }

  } 
  else
  {
    $_SESSION['reply'] = "Please fill in all the fields";
  }
  unset($_POST[$id_reply]);
  unset($_POST['reply']);
}
else
{
  $_SESSION['reply'] = 'Please login first';
}

header('Location: index.php#'.$id_title.'@');

?>
