<?php
if(isset($_FILES['hello']))
{
	echo $_FILES['hello']['name'];
}
?>

<form enctype="multipart/form-data" action='som.php' method='post'>
<input type="file" name="hello">
<input type="submit" value="submit">
</form>