<?php
	if(isset($_POST['Sports']))
	{	
		unset($_POST['Sports']);
		header('Location:sports.php');
	}
	else if(isset($_POST['Events']))
		{	
		unset($_POST['Events']);
		header('Location:events.php');
	}
	else if(isset($_POST['Academics']))
		{	
		unset($_POST['Academics']);
		header('Location:academics.php');
	}
	else if(isset($_POST['Personal']))
		{	
		unset($_POST['Personal']);
		header('Location:personal.php');
	}
	else if(isset($_POST['Entertainment']))
		{	
		unset($_POST['Entertainment']);
		header('Location:entertainment.php');
	}

?>