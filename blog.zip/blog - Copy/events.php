<?php
ob_start();
session_start();
require 'connect.php';
//include 'login.php';
unset($_SESSION['title1']);
unset($_SESSION['content1']);
if(isset($_SESSION['user_id']) && !empty($_SESSION['user_id']))
{
  $login=$_SESSION['username'];
  $go="profile.php";
}
else
{
  $login='Login/Register';
  $go="login.php"; 
}

//echo $_SESSION['profile_pic'];
?>




<!doctype html>
<html>
<head>
 <title>NITK Speaks</title> 
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="description" content="This is NITK blog website. It is for NITK blogging. Exclusively for NITK students.">
 <meta name="keywords" content="NITK blog, NITK blogging, NITK speaks, NITK forum, NITK">
 <meta name="robots" content="INDEX,FOLLOW">

 <!-- Bootstrap -->
 <link href="css/bootstrap.min.css" rel="stylesheet">
 <!-- your layout style -->
 <link rel="stylesheet" type="text/css" href="main.css">

 <script type="text/javascript">
 

function showUser(ele) {
      //alert(ele.id);
      var id=ele.id;
      var id1=id-5000;
        if (window.XMLHttpRequest) {
            
            xmlhttp = new XMLHttpRequest();
        } else {
            
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById(id).innerHTML = this.responseText;
            }
        };

        xmlhttp.open("GET","upvote.php?q="+id1,true);
        xmlhttp.send();
    
}

function showUser1(ele) {
      //alert(ele.id);
      var id=ele.id;
      var id1=id-6000;
        if (window.XMLHttpRequest) {
            
            xmlhttp = new XMLHttpRequest();
        } else {
            
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById(id).innerHTML = this.responseText;
            }
        };

        xmlhttp.open("GET","downvote.php?q="+id1,true);
        xmlhttp.send();
    
}



 function reply(ele)
 {
  //alert(ele.name);
  var form = document.createElement("form");
  form.action="forreply.php";
  form.method="POST";
  var text = document.createElement("textarea");
  text.rows="5";
  text.class="form-control";
  text.cols="50";
  text.name=ele.name;
  var submit = document.createElement("input");
  submit.type="submit";
  submit.name="reply";
  submit.class="btn btn-success";
  submit.value="Submit";
  form.appendChild(text);
  form.appendChild(submit);

  var main = document.getElementById(ele.name);   
  main.removeChild(main.childNodes[0]);  
  document.getElementById(ele.name).appendChild(form);
 }
 </script>
</head>
<body>
 

<!--header starts-->
<div style="margin:0px;" class="">
<nav class="navbar navbar-default header navbar-static-top " role="navigation" style="padding:20px 20px 20px 20px;">

  <div class="container">
    
    <div class="navbar-header navbar-left">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php" style="color:; font-size:30px; font-family:Georgia;">NITK Speaks</a>
    </div>

   
    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
      
      <form class="navbar-form navbar-left" action="search.php" method="Post" role="search">
        <div class="form-group">
          <input type="text" class="form-control" name="search" placeholder="Search Topics">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="blog.php">Create Blog</a></li>
        <li><a href=<?php echo $go;?>><?php echo $login; ?></a></li>
        <?php if(isset($_SESSION['username'])){ 
        echo '<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class=" glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span></a>
          <ul class="dropdown-menu">
            <li><a href="yourblog.php">Your Blogs</a></li>
            <li><a href="profile.php">Your Profile</a></li>
            <li><a href="editprofile.php">Edit Profile</a></li>
            <li><a href="changepassword.php">Change Password</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>';
      }
        ?>
      </ul>
    </div>
  </div>
</nav>

</div>

<!--header ends-->

<!--body starts--> 

<div class="main" style="top:50;" >
  <div class="main1" style="vertical-align:middle;">
 <div style="margin:100px 0px 10px 0px; color: #fff; padding: 20px; text-align:center;"><h1><strong>Welcome to NITK Speaks</strong></h1></div>
  <div style="background-color:#fff;  width:80px; height:2px; margin: 0 auto; "></div>
  
  <div style="margin:60px 0px 0px 0px; color: #fff; font-style:times; text-align: center; font-size:20px;"><strong><h2>Hey There! Speak your heart out!</h2></strong></div>

  <div style="margin:0px 0px 40px 0px; padding: 20px 80px 20px 80px; color: #fff; font-style:times; text-align: center; font-size:20px;"><strong><h2>NITK speaks is a community of readers and writers offering unique perspectives on ideas large and small.</h2></strong></div>
  </div>
</div>


<?php
if(isset($_SESSION['blog']) && !empty($_SESSION['blog']))
{
  echo 'Your blog is successfully submitted!';
  unset($_SESSION['blog']);
}

?>


<?php
if(isset($_SESSION['reply']) && !empty($_SESSION['reply']))
{
  echo $_SESSION['reply'];
  unset($_SESSION['reply']);
}

?>

<?php
if(isset($_SESSION['delete']) && !empty($_SESSION['delete']))
{
  echo $_SESSION['delete'];
  unset($_SESSION['delete']);
}

if(isset($_SESSION['delete1']) && !empty($_SESSION['delete1']))
{
  echo $_SESSION['delete1'];
  unset($_SESSION['delete1']);
}
if(isset($_SESSION['change1']) && !empty($_SESSION['change1']))
{
  echo $_SESSION['change1'];
  unset($_SESSION['change1']);
}
?>
  
<!--blog backend starts-->
<div class="row" style="background-color:#FCFAFA; padding:40px 120px 40px 120px;" >

<div  class="col-md-8 " style="margin:0px 50px 0px 0px;">
<div class="box" style="margin:0px 0px 30px 0px;">

<img  src=<?php if(isset($_SESSION['profile_pic'])){echo 'pics/'.$_SESSION['profile_pic'];} ?> style=<?php if(isset($_SESSION['profile_pic'])){echo "display:block;";} ?> class="img-circle hey" height="50" width="50">
<p style="font-size:25px;">Personalize your reading list</p>
<p style="color:rgba(0, 0, 0, 0.4);">Discover people, ideas, and topics that matter to you</p>
<form style="display:inline-block" action="divide.php" method="POST">
<button class="btn " name="Sports" type="submit" style="margin:0px 0px 0px 10px; color: #fff; background-color:#00ab6b;">Sports</button>
</form>
<form style="display:inline-block" action="divide.php" method="POST">
<button name="Events"  type="submit" class="btn " style="margin:0px 0px 0px 10px; color: #fff; background-color:#00ab6b;">NITK Events</button>
</form>
<form style="display:inline-block" action="divide.php" method="POST">
<button class="btn " name="Academics" type="submit" style="margin:0px 0px 0px 10px; color: #fff; background-color:#00ab6b;">Academics</button>
</form>
<form style="display:inline-block" action="divide.php" method="POST">
<button class="btn " type="submit" name="Entertainment" style="margin:0px 0px 0px 10px; color: #fff; background-color:#00ab6b;">Entertainment</button>
</form>
<form style="display:inline-block" action="divide.php" method="POST">
<button class="btn " type="submit" name="Personal" style="margin:0px 0px 0px 10px; color: #fff; background-color:#00ab6b;">Personal</button>
</form>
<button class="btn btn-default" style="margin:0px 0px 0px 10px; color:rgba(0, 0, 0, 0.4) ; background-color:rgba(0, 0, 0, 0.2);">Later</button>
</div>
<?php

  $query="SELECT * FROM `blogs`";
  if($query_run=mysql_query($query))
  {
    $rows=mysql_num_rows($query_run);
    if($rows>0)
    {
    $queryy="SELECT `nob` FROM `nob`";
    $queryyrun=mysql_query($queryy);
    $data=mysql_fetch_assoc($queryyrun);
    $nob=$data['nob'];
      for($x=$nob;$x>0;$x--)
      {
        
        $query1="SELECT * FROM `blogs` WHERE `id`="."'".$x."'";
        $query2="SELECT * FROM `replies` WHERE `id_title`="."'".$x."'";
        $query_run1=mysql_query($query1);
        $query_run2=mysql_query($query2);
        $data=mysql_fetch_assoc($query_run1);
        
        $type=$data['type'];
        $username=$data['username'];
        if(!empty($username) && $type=='NITK Events'){
        $title=$data['title'];
        $content=$data['content'];
        $datetime=$data['datetime'];
        $pic=$data['image'];
        $pic1=$data['video'];
        $pic2=$data['doc'];
        $type=$data['type'];
        $id=$data['id'];
        $upvote=$data['upvote'];
        $downvote=$data['downvote'];
        $id1=$id+1000;
        $id2=$id+2000;
        $id3=$id+3000;
        $id4=$id+4000;
        $id5=$id+5000;
        $id6=$id+6000;

        $query3="SELECT `profile_pic` FROM `user` WHERE `username`="."'".$username."'";
        $query_run3=mysql_query($query3);
        $data=mysql_fetch_assoc($query_run3);
        $profile_pic=$data['profile_pic'];
        $a=0;
        //echo $profile_pic;
        if(isset($_SESSION['username'])){
        if($_SESSION['username']==$username)
        $a=1;  
        }

        echo "<div  class='box' name='".$id."@' id='".$id."@' >";
        echo "<img src="."'pics/".$profile_pic."'  class='img-circle ' style='float:left; margin:0px 20px 0px 0px;' height='50' width='50'".">";
        if($a==1){
          
        echo "<div class='collapse navbar-collapse navbar-right' id='bs-example-navbar-collapse-1'>
      
      
      <ul class='nav navbar-nav navbar-right'>
        
        <li class='dropdown'>
        <a href='#' style='font-size:15px; float:right; color:rgba(0, 0, 0, 0.4);' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='glyphicon glyphicon-menu-hamburger' aria-hidden='true'></span></a>
          <ul class='dropdown-menu'>
          <form method='POST' action='editblog.php'>
            <li><button type='submit' id='".$id1."' name='".$id1."' style='font-size:15px; border:0px solid #000; background-color:#fff; color:rgba(0, 0, 0, 0.4); margin:0px 0px 0px 0px;' >Edit</button></li>
          </form>
          <form method='POST' action='deleteblog.php'>  
            <li><button id='".$id2."' name='".$id2."' style='font-size:15px; border:0px solid #000; background-color:#fff; color:rgba(0, 0, 0, 0.4); margin:0px 0px 0px 0px;' >Delete</button></li>
          </form>  
          </ul>
          </li>
            </ul>
    </div>";

      }
        echo "<p style=' color:#00ab6b; font-size:20px; margin:0px 5px 0px 10px;'>"." ".$username."</p>";
        echo "<p style='font-size:15px; color:rgba(0, 0, 0, 0.4); margin:0px 0px 0px 0px;' >"."at ".$datetime."</p>";
        
        echo "<br><h2><strong>".$title."</strong></h2>";
        echo "<br><p style='font-size:20px;'>".$content."</p><br>";
        if(!empty($pic))
        echo "<img src='pics/".$pic."' class='imga'><br><hr>";
        if(!empty($pic1))
        echo "<video class='imga' controls> <source src='pics/".$pic1."' type='video/ogg' ></video><br><hr>";
        if(!empty($pic2))
        echo "<a href='pics/".$pic2."' class='imga'>".$pic2."</a><br><hr>";
        //echo $type;
        echo  "<button id='".$id5."' class='upvote' onclick='showUser(this)'  style='border:0px solid white; background-color:white;'><span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-up' aria-hidden='true'    >"." ".$upvote.""."</span></button>";
        echo  "<button id='".$id6."' class='downvote' onclick='showUser1(this)' style='border:0px solid white; background-color:white;'><span class='downvote glyphicon glyphicon-thumbs-down' aria-hidden='true'  style='margin:0px 0px 0px 0px;'>"." ".$downvote.""."</span></button>";
        echo "<br><br><h5><strong style='color:#2E4053;'>Responses</strong></h5><br>";
        echo "<ul>";
        while($data1=mysql_fetch_assoc($query_run2)) 
        { 
          $username1 = $data1['username'];
          $reply1 = $data1['reply'];
          $id4 = $data1['id'];
          $datetime_reply = $data1['datetime'];
          $b=0;
          if(isset($_SESSION['username'])){
        if($_SESSION['username']==$username1)
        $b=1;  
        }

          if($b==1){
          
        echo "<div class='collapse navbar-collapse navbar-right' id='bs-example-navbar-collapse-1'>
      
      
      <ul class='nav navbar-nav navbar-right'>
        
        <li class='dropdown'>
        <a href='#' style='font-size:15px; float:right; color:rgba(0, 0, 0, 0.4);' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='glyphicon glyphicon-menu-hamburger' aria-hidden='true'></span></a>
          <ul class='dropdown-menu'>
          
          <form method='POST' action='deletereply.php'>
            <li><button type='submit'  id='".$id4."' name='".$id4."' style='font-size:15px; border:0px solid #000; background-color:#fff; color:rgba(0, 0, 0, 0.4); margin:0px 0px 0px 0px;' >Delete</button></li>
          </form>

          </ul>
          </li>
            </ul>
    </div>";

      }

          echo "<li style='color:#00ab6b;'>".$username1."<br> <p style='font-size:12px; color:rgba(0, 0, 0, 0.4);'>at ".$datetime_reply."</p><p style='color:black; font-size:18px;'>".$reply1."</p></li>"; 
        }
        echo "</ul>";


        echo "<div  id="."'".$id."'"." >";
        echo "<button type='button' name="."'".$id."'"." class='btn btn-primary btn-xs' style='background-color:#00ab6b;' onclick='reply(this);'>Reply</button>";
        echo "</div>";
        echo "</div>";
        echo "<br>";
      }
      else
      {

      }
    }

    }
    else
    {
      echo "<div  class='container'>";
      echo 'no posts to show';
      echo "</div>";
    }
  }
  else
  {
    echo 'wrong query';
  }
  


?>
</div>

<div class="col-md-3 " style="background-color:#FCFAFA; height:900px;">
  <div style="padding:0px 0px 0px 0px;"><strong>News and Events</strong></div>
  <div style="color:rgba(0, 0, 0, 0.4); padding:0px 0px 10px 0px; font-size:12px;">The nitk events coming weeks</div>
  <div style="background-color:rgba(0, 0, 0, 0.1);  width:180px; height:1px; margin:; "></div>
  <div style="margin:20px 0px 0px 0px; font-size:12px;">
  <div style=" margin:20px 0px 0px 0px;">
   <img src="pics/Engineer_logo.png" class="img-circle" height="30" width="40"><a href="http://www.engineer-nitk.org" style="color:#000; text-decoration:none;">Engineer(19th-24th October)</a>
  </div>
  <div style=" margin:20px 0px 0px 0px;">
   <img src="pics/nitk.jpg" class="img-circle" height="30" width="40"><a href="http://nitk.ac.in" style="color:#000; text-decoration:none;"> Class-committee meeting(17th-18th October)</a>
  </div>
  
</div>



  <div style="margin:40px 0px 0px 0px;  padding:0px 0px 0px 0px;"><strong>Stories worth talking about</strong></div>
  <div style="color:rgba(0, 0, 0, 0.4); padding:0px 0px 10px 0px; font-size:12px;">The stories you might have missed this week</div>
  <div style="background-color:rgba(0, 0, 0, 0.1);  width:180px; height:1px; margin:; "></div>
  <div style="margin:20px 0px 0px 0px; font-size:12px;">
  <div style=" margin:20px 0px 0px 0px;">
   <img src="pics/india.jpg" class="img-circle" height="30" width="40">  The Surgical attacks by india
  </div>
  <div style=" margin:20px 0px 0px 0px;">
   <img src="pics/ind-nz.jpg" class="img-circle" height="30" width="40">  India vs Newzealand
  </div>
  
</div>

  <div style="margin:40px 0px 0px 0px;  padding:0px 0px 0px 0px;"><strong>Highest Rated Posts</strong></div>
  <div style="color:rgba(0, 0, 0, 0.4); padding:0px 0px 10px 0px; font-size:12px;">The best story of the week</div>
  <div style="background-color:rgba(0, 0, 0, 0.1);  width:180px; height:1px; margin:; "></div>
  <div style="margin:20px 0px 0px 0px; font-size:12px;">
  
  <?php
  $query = "SELECT * FROM `blogs` ORDER BY `upvote` DESC, `downvote` ASC LIMIT 2";
  $queryrun=mysql_query($query);
  while($data=mysql_fetch_assoc($queryrun))
  {

    $title=$data['title'];
    $username=$data['username'];
    $id=$data['id'].'@';
    $query1 = "SELECT `profile_pic` FROM `user` WHERE `username`='".$username."'";
    if($queryrun1=mysql_query($query1)){
    $data1=mysql_fetch_assoc($queryrun1);
    $profile_pic=$data1['profile_pic'];
  }
    echo '
    <div style=" margin:20px 0px 0px 0px;">
     <img src="pics/'.$profile_pic.'" class="img-circle" height="30" width="40"><strong style="font-size:15px; font-weight:20;"> '.$title.'</strong>  
   <div style="color:rgba(0, 0, 0, 0.4); margin-left:42px;">by '.$username.'</div>
  </div>';
  }

?>
  
  
  
</div>
</div>
</div>
<!--blog backend ends-->

<!--footer starts-->
<div class="footer1" style="">
<div class="footer-line">

<div style=" margin:50px 0px 30px 550px;">
<div style="display:inline; margin:20px;"><img class="img-circle" src="pics/fb.jpg"  width="40" height="40"></div>
<div style="display:inline; margin:20px;"><img class="img-circle"  src="pics/twitter.jpg"   width="40" height="40"></div>
<div style="display:inline; margin:20px;"><img class="img-circle"  src="pics/google.jpg"   width="40" height="40"></div>
</div>

<div class="row" style="margin-left:0px;  font-family:times; color:#fff; text-align:center;">
  <div class="col-md-4">
    <p style=" padding:20px; font-size:20px;"><strong>Quick Links</strong></p>
    <div style="text-align:left; margin-left:100px; padding:0px 0px 20px 20px;">
    <ul>
    <li><a href="#">Terms & Conditions</a></li>
    <li><a href="#">Privacy Policies</a></li>
    <li><a href="#">Grievances</a></li>
    <li><a href="#">Careers</a></li>
    <li><a href="#">Contact Us</a></li>
    </ul>
    </div>
  </div>
  <div class="col-md-4">
    <p style=" padding:20px;  font-size:20px;"><strong>Other links</strong></p>
    <div style="text-align:left; margin-left:100px; padding:0px 0px 20px 20px;">
    <ul>
    <li><a href="#">Create Blog</a></li>
    <li><a href="#">Your Blogs</a></li>
    <li><a href="#">Something Else</a></li>
    </ul>
    </div>
  </div>
  <div class="col-md-4">
    <p style=" padding:20px;  font-size:20px;"><strong>Contact Us</strong></p>
    <address style="font-size:15px;">
    <em>#C204,Mt-1,NITK  <br>
    SrinivasNagar, Surathkal<br>
    Mangalore pin code - 575025<br>
    9591725899<br>
    enquiry@amit-edu.in
    </em></address>
  </div>
</div>



</div>


<div style="text-align:center;"><br><br><br>
  <p style="font-size:30px;  color: #00ab6b; font-family:cursive;">Some Tagline that NITK uses</p>
  <button  class="btn btn-default btn-lg" style="background:#00ab6b;color: #fff;">MAIL US</button><br><br>
  <p>© NITK Speaks Private Limited 2016</p>
</div><br>
<div style="display:inline-block; float:right; margin:0px 40px 0px 0px;">
  
</div>
</div>

 
<!--footer ends-->

  <!-- Js in bottom so the DOM will laod Faster-->
 <script src="https://code.jquery.com/jquery-2.1.1.js" integrity="sha256-FA/0OOqu3gRvHOuidXnRbcmAWVcJORhz+pv3TX2+U6w=" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js"></script>
  <script >
  
    $(window).load(function () {
                      
  
        $('.upvote').click(function()
        {
          var id=this.id;
          $.ajax({
            url: "upvote.php",
            type:"POST",
            data:
            {
              id:"hello"; 
            }
            
          }).done(function(){alert("hello");});
        }
        );  

        });
  </script>
</body>
</html>