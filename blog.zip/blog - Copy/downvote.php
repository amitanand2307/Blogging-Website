<?php
ob_start();
session_start();
require 'connect.php';

$q = intval($_GET['q']);

if(isset($_SESSION['user_id'])){
$query="SELECT * FROM `upvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";
$query_run=mysql_query($query);
$rows1=mysql_num_rows($query_run);
$query="SELECT * FROM `downvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";
$query_run=mysql_query($query);
$rows=mysql_num_rows($query_run);

if($rows1!=0)
{
$query="SELECT `downvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$downvote=$data['downvote'];	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-down' aria-hidden='true' onclick='showUser(this)'   >"." ".$downvote.""."</span>";

}
else{
if($rows==0)
{
	$query="SELECT `downvote` FROM `blogs` WHERE `id`="." '".$q."' ";
	$query_run=mysql_query($query);
	$data=mysql_fetch_assoc($query_run);
	$downvote=$data['downvote']+1;
	$query="UPDATE `blogs` SET `downvote`="." '".$downvote."' WHERE `id`="." '".$q."' ";
	$query_run=mysql_query($query);	
	$query="INSERT INTO  `downvote` VALUES(".$_SESSION['user_id'].", ".$q.")" ;	
	$query_run=mysql_query($query);
	echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-down' aria-hidden='true' onclick='showUser(this)'   >"." ".$downvote.""."</span>";

}


else
{
$query="SELECT `downvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$downvote=$data['downvote']-1;
$query="UPDATE `blogs` SET `downvote`="." '".$downvote."' WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);	
$query="DELETE FROM `downvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";	
$query_run=mysql_query($query);	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-down' aria-hidden='true' onclick='showUser(this)'   >"." ".$downvote.""."</span>";

}
}
}
else
{
	$query="SELECT `downvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$downvote=$data['downvote'];	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-down' aria-hidden='true' onclick='showUser(this)'   >"." ".$downvote.""."</span>";
}

?>