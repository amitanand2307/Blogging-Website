<?php
ob_start();
session_start();
require 'connect.php';
//include 'login.php';
if(isset($_SESSION['user_id']) && !empty($_SESSION['user_id']))
{
  $login=$_SESSION['username'];
  $go="profile.php";
}
else
{
  $login='Login/Register';
  $go="login.php"; 
}
?>

<!doctype html>
<html>
<head>
 <title>Blog</title> 
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">

 <!-- Bootstrap -->
 <link href="css/bootstrap.min.css" rel="stylesheet">

 <link rel="stylesheet" type="text/css" href="blog.css">
</head>

<body>


  <!--header starts-->
  <div style="margin:0px;" class="">
    <nav class="navbar navbar-default header navbar-static-top " role="navigation" style="padding:20px 20px 20px 20px;">

      <div class="container">

        <div class="navbar-header navbar-left">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php" style="color:; font-size:30px; font-family:Georgia;">NITK Speaks</a>
        </div>


        <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">

          <form class="navbar-form navbar-left" action="search.php" method="Post" role="search">
            <div class="form-group">
              <input type="text" class="form-control" name="search" placeholder="Search Topics">
            </div>
            <button type="submit" class="btn btn-default">Submit</button>
          </form>
          <ul class="nav navbar-nav navbar-right">
        <li><a href="blog.php">Create Blog</a></li>
        <li><a href=<?php echo $go;?>><?php echo $login; ?></a></li>
        <?php if(isset($_SESSION['username'])){ 
        echo '<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class=" glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span></a>
          <ul class="dropdown-menu">
            <li><a href="yourblog.php">Your Blogs</a></li>
            <li><a href="profile.php">Your Profile</a></li>
            <li><a href="editprofile.php">Edit Profile</a></li>
            <li><a href="changepassword.php">Change Password</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>';
      }
        ?>
      </ul>
        </div>
      </div>
    </nav>

  </div>

  <!--header ends-->


  <div class="main" style="top:50;" >
    <div class="main1" style="vertical-align:middle;">
     <div style="margin:100px 0px 10px 0px; color: #fff; padding: 20px; text-align:center;"><h1><strong>Welcome to NITK Speaks</strong></h1></div>
     <div style="background-color:#fff;  width:80px; height:2px; margin: 0 auto; "></div>

     <div style="margin:60px 0px 0px 0px; color: #fff; font-style:times; text-align: center; font-size:20px;"><strong><h2>Hey There! Speak your heart out!</h2></strong></div>

     <div style="margin:0px 0px 40px 0px; padding: 20px 80px 20px 80px; color: #fff; font-style:times; text-align: center; font-size:20px;"><strong><h2>Medium is a community of readers and writers offering unique perspectives on ideas large and small.</h2></strong></div>
   </div>
 </div>


 <!--blog backend-->

 <?php
 if(isset($_POST['submit']))
 {
  if(isset($_SESSION['user_id']))
  {
    if(isset($_POST['title']) && !empty($_POST['title']) && isset($_POST['content']) && !empty($_POST['content']) && isset($_FILES['media']) && !empty($_FILES['media']) && isset($_FILES['media1']) && !empty($_FILES['media1']) && isset($_FILES['media2']) && !empty($_FILES['media2']) && isset($_POST['type']) && !empty($_POST['type']))
    {
      $title = $_POST['title'];
      $content = $_POST['content'];
      $username = $_SESSION['username'];
      $type=$_POST['type'];
      $target_dir = 'pics/';
      $pic_name= $_FILES['media']['name'];
      $tmp_name = $_FILES['media']['tmp_name'];
      $pic_name1= $_FILES['media1']['name'];
      $tmp_name1 = $_FILES['media1']['tmp_name'];
      $pic_name2= $_FILES['media2']['name'];
      $tmp_name2 = $_FILES['media2']['tmp_name'];
    //$target_file = $target_dir.basename($_FILES['image']['name']);
    //$uploadOk = 1;
    //$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

      move_uploaded_file($tmp_name, $target_dir.$pic_name);
      move_uploaded_file($tmp_name1, $target_dir.$pic_name1);
      move_uploaded_file($tmp_name2, $target_dir.$pic_name2);
      $pic=basename( $pic_name);
      $pic1=basename( $pic_name1);
      $pic2=basename( $pic_name2);
      $query="INSERT INTO `blogs` (title,content,username,image,video,doc,type) VALUES("."'".$title."'".","."'".$content."'".","."'".$username."'".","."'".$pic."'".","."'".$pic1."'".","."'".$pic2."'".","."'".$type."'".")";

      if($query_run=mysql_query($query))
      {

        $_SESSION['blog']=$username;
        $_SESSION['content']=$content;
        $_SESSION['title']=$title;
        $queryy="SELECT `nob` FROM `nob`";
        $queryyrun=mysql_query($queryy);
        $data=mysql_fetch_assoc($queryyrun);
        $nob=$data['nob']+1;
        $nob1=$data['nob'];
        $queryy="UPDATE `nob` SET `nob`=".$nob." WHERE `nob`=".$nob1;
        $queryyrun=mysql_query($queryy);

        header("Location: index.php");
      } 
      else
      {
        echo 'wrong query';
      }

    } 
    else
    {
      echo "Please fill in all the fields";
    }
  }
  else
  {
    echo 'Please login first';
  }
}

?>

<!--blog backend ends-->



<!--blog starts-->
<div  style="margin:60px 80px 60px 80px;">
  <div style="color:#00ab6b; font-family: georgia; font-size:30px; margin:20px 0px 20px 0px;">Write your Story</div>
  <div class="box">
    <form enctype="multipart/form-data" method="Post" action="blog.php">
      <div class="form-group">
        <label for="exampleInputEmail1">Title</label>
        <input type="text" name="title" class="form-control" id="exampleInputEmail1" placeholder="Title">
      </div>
      <div class="form-group">
        <label for="comment">Content</label>
        <textarea  class="form-control" name="content" id="exampleInputPassword1" placeholder="Write your content here" cols="50" rows="15"></textarea>
      </div>
      <div style="display:inline-block;" class="form-group">
        <label for="exampleInputFile">Pics</label>
        <input type="file" name="media" id="exampleInputFile">
        <p class="help-block">optional</p>
      </div>
      <div class="form-group" style="display:inline-block;">
        <label for="exampleInputFile">Videos</label>
        <input type="file" name="media1" id="exampleInputFile">
        <p class="help-block">optional</p>
      </div>
      <div class="form-group" style="display:inline-block;">
        <label for="exampleInputFile">Docs</label>
        <input type="file" name="media2" id="exampleInputFile">
        <p class="help-block">optional</p>
      </div>
      <div class="form-group" style="width:10%;">
        <select id='a' class="form-control" name="type" placeholder="">
          <option>Sports</option>
          <option>NITK Events</option>
          <option>Academic</option>
          <option>Entertainment</option>
          <option>Personal</option>
        </select>
      </div><br> 
      <button style="display:block;" type="submit" name="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
</div>
<!--blog ends-->

<!--footer starts-->
<div class="footer1" >
  <div class="footer-line">

    <div style=" margin:50px 0px 30px 550px;">
      <div style="display:inline; margin:20px;"><img class="img-circle" src="pics/fb.jpg"  width="40" height="40"></div>
      <div style="display:inline; margin:20px;"><img class="img-circle"  src="pics/twitter.jpg"   width="40" height="40"></div>
      <div style="display:inline; margin:20px;"><img class="img-circle"  src="pics/google.jpg"   width="40" height="40"></div>
    </div>

    <div class="row" style="margin-left:0px;  font-family:times; color:#fff; text-align:center;">
      <div class="col-md-4">
        <p style=" padding:20px; font-size:20px;"><strong>Quick Links</strong></p>
        <div style="text-align:left; margin-left:100px; padding:0px 0px 20px 20px;">
          <ul>
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Privacy Policies</a></li>
            <li><a href="#">Grievances</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-4">
        <p style=" padding:20px;  font-size:20px;"><strong>Other links</strong></p>
        <div style="text-align:left; margin-left:100px; padding:0px 0px 20px 20px;">
          <ul>
            <li><a href="#">Create Blog</a></li>
            <li><a href="#">Your Blogs</a></li>
            <li><a href="#">Something Else</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-4">
        <p style=" padding:20px;  font-size:20px;"><strong>Contact Us</strong></p>
        <address style="font-size:15px;">
          <em>#C204,Mt-1,NITK  <br>
            SrinivasNagar, Surathkal<br>
            Mangalore pin code - 575025<br>
            9591725899<br>
            enquiry@amit-edu.in
          </em></address>
        </div>
      </div>



    </div>


    <div style="text-align:center;"><br><br><br>
      <p style="font-size:30px;  color: #00ab6b; font-family:cursive;">Some Tagline that NITK uses</p>
      <button  class="btn btn-default btn-lg" style="background:#00ab6b;color: #fff;">MAIL US</button><br><br>
      <p>© NITK Speaks Private Limited 2016</p>
    </div><br>
    <div style="display:inline-block; float:right; margin:0px 40px 0px 0px;">

    </div>


    <script src="https://code.jquery.com/jquery-2.1.1.js" integrity="sha256-FA/0OOqu3gRvHOuidXnRbcmAWVcJORhz+pv3TX2+U6w=" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js"></script>
  
  </body>
  </html>