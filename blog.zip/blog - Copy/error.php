<!doctype html>
<html>
<head>
 <title>ERROR 404 NOT FOUND</title> 
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">

 <!-- Bootstrap -->
 <link href="css/bootstrap.min.css" rel="stylesheet">
 <!-- your layout style -->
 <link rel="stylesheet" type="text/css" href="/blog/main.css">

</head>
<body>
  
<!--navbar-->  
<nav class="navbar navbar-inverse navbar-static-top no-margin no-padding" role="navigation">
  <div class="container">
    
    <div class="navbar-header navbar-left">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">NITK Speaks</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
      
      <form class="navbar-form navbar-left" action="search.php" method="Post" role="search">
        <div class="form-group">
          <input type="text" class="form-control" name="search" placeholder="Search Topics">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="blog.php">Create Blog</a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="yourblog.php">Your Blogs</a></li>
            <li><a href="profile.php">Your Profile</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--navbar end-->

<div class="container">

<h1><strong>PAGE NOT FOUND</strong></h1>
<h3>ERROR 404</h3>
<br>

<a href="index.php" class="btn btn-danger btn-info"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Take Me Home</a>



</div>

 <script src="https://code.jquery.com/jquery-2.1.1.js" integrity="sha256-FA/0OOqu3gRvHOuidXnRbcmAWVcJORhz+pv3TX2+U6w=" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>