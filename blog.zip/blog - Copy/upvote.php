<?php
ob_start();
session_start();
require 'connect.php';

$q = intval($_GET['q']);

if(isset($_SESSION['user_id'])){
$query="SELECT * FROM `upvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";
$query_run=mysql_query($query);
$rows=mysql_num_rows($query_run);
$query="SELECT * FROM `downvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";
$query_run=mysql_query($query);
$rows1=mysql_num_rows($query_run);

if($rows1!=0)
{
$query="SELECT `upvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$upvote=$data['upvote'];	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-up' aria-hidden='true' onclick='showUser(this)'   >"." ".$upvote.""."</span>";
}
else{
if($rows==0)
{
	$query="SELECT `upvote` FROM `blogs` WHERE `id`="." '".$q."' ";
	$query_run=mysql_query($query);
	$data=mysql_fetch_assoc($query_run);
	$upvote=$data['upvote']+1;
	$query="UPDATE `blogs` SET `upvote`="." '".$upvote."' WHERE `id`="." '".$q."' ";
	$query_run=mysql_query($query);	
	$query="INSERT INTO  `upvote` VALUES(".$_SESSION['user_id'].", ".$q.")" ;	
	$query_run=mysql_query($query);
	echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-up' aria-hidden='true' onclick='showUser(this)'   >"." ".$upvote.""."</span>";

}

else
{
$query="SELECT `upvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$upvote=$data['upvote']-1;
$query="UPDATE `blogs` SET `upvote`="." '".$upvote."' WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);	
$query="DELETE FROM `upvote` WHERE `blog_id`="." '".$q."' AND `user_id`="." '".$_SESSION['user_id']."' ";	
$query_run=mysql_query($query);	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-up' aria-hidden='true' onclick='showUser(this)'   >"." ".$upvote.""."</span>";

}

}
}
else{
	$query="SELECT `upvote` FROM `blogs` WHERE `id`="." '".$q."' ";
$query_run=mysql_query($query);
$data=mysql_fetch_assoc($query_run);
$upvote=$data['upvote'];	
echo "<span   style='margin:0px 20px 0px 0px;' class=' glyphicon glyphicon-thumbs-up' aria-hidden='true' onclick='showUser(this)'   >"." ".$upvote.""."</span>";	
}




?>